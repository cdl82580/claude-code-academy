# web-widgets-starter

Three tiny, dependency-free UI widgets (a counter, a to-do list, and a tab switcher) in plain
HTML/CSS/JS. No build step, no npm install.

## Run it

Just open `index.html` in a browser. Or serve it locally:

```bash
python3 -m http.server 8080
```

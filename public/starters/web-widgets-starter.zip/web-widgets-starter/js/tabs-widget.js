// Tabs widget. Style note: no semicolons, var/let mixed in (inconsistent with the other two files)

var mountTabsWidget = function (root) {
  let tabs = ["Overview", "Details", "Notes"]
  let active = 0

  let tabBar = createEl("div", "tabs-bar")
  let panel = createEl("div", "tabs-panel")

  function render() {
    tabBar.innerHTML = ""
    tabs.forEach(function (label, index) {
      let btn = createEl("button", "tabs-btn")
      btn.textContent = label
      if (index === active) btn.classList.add("tabs-btn-active")
      btn.addEventListener("click", function () {
        active = index
        render()
      })
      tabBar.appendChild(btn)
    })
    panel.textContent = tabs[active] + " content goes here."
  }

  render()

  root.appendChild(tabBar)
  root.appendChild(panel)
}

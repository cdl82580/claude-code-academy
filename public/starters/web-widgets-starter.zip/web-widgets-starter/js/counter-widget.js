// Counter widget. Style note: function declarations, consistent semicolons.

function mountCounterWidget(root) {
  let count = 0;

  const display = createEl("p", "counter-display");
  const incBtn = createEl("button", "counter-btn");
  const decBtn = createEl("button", "counter-btn");

  incBtn.textContent = "+";
  decBtn.textContent = "-";

  function render() {
    display.textContent = String(count);
  }

  incBtn.addEventListener("click", function () {
    count += 1;
    render();
  });

  decBtn.addEventListener("click", function () {
    count -= 1;
    render();
  });

  render();

  root.appendChild(decBtn);
  root.appendChild(display);
  root.appendChild(incBtn);
}

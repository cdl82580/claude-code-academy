// Shared helpers used across all three widgets.

function createEl(tag, className) {
  const el = document.createElement(tag);
  if (className) el.className = className;
  return el;
}

function formatCount(n) {
  return n === 1 ? "1 item" : `${n} items`;
}

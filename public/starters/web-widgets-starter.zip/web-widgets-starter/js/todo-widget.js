// To-do widget. Style note: arrow functions throughout (inconsistent with counter-widget.js).

const mountTodoWidget = (root) => {
  const items = [];

  const list = createEl("ul", "todo-list");
  const count = createEl("p", "todo-count");
  const input = createEl("input", "todo-input");
  const addBtn = createEl("button", "todo-add");

  input.placeholder = "Add a task";
  addBtn.textContent = "Add";

  const render = () => {
    list.innerHTML = "";
    items.forEach((item, index) => {
      const li = createEl("li", "todo-item");
      li.textContent = item;

      const removeBtn = createEl("button", "todo-remove");
      removeBtn.textContent = "x";
      removeBtn.addEventListener("click", () => {
        items.splice(index, 1);
        render();
      });

      li.appendChild(removeBtn);
      list.appendChild(li);
    });
    count.textContent = formatCount(items.length);
  };

  const addItem = () => {
    const value = input.value.trim();
    if (!value) return;
    items.push(value);
    input.value = "";
    render();
  };

  addBtn.addEventListener("click", addItem);
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") addItem();
  });

  render();

  root.appendChild(input);
  root.appendChild(addBtn);
  root.appendChild(count);
  root.appendChild(list);
};

# node-api-starter

A tiny in-memory REST API with two resources (notes and tasks). No database — everything
resets when the server restarts.

## Run it

```bash
npm install
npm start
```

Server listens on `http://localhost:3000`.

## Endpoints

- `GET /notes` / `POST /notes` / `DELETE /notes/:id`
- `GET /tasks` / `POST /tasks` / `DELETE /tasks/:id`

## Tests

```bash
npm test
```

const express = require("express");
const notesRouter = require("./routes/notes");
const tasksRouter = require("./routes/tasks");

const app = express();
app.use(express.json());

app.get("/", (req, res) => {
  res.json({ ok: true, resources: ["/notes", "/tasks"] });
});

app.use("/notes", notesRouter);
app.use("/tasks", tasksRouter);

const PORT = process.env.PORT || 3000;

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`node-api-starter listening on http://localhost:${PORT}`);
  });
}

module.exports = app;

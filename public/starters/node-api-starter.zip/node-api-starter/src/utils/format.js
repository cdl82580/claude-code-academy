// Shared formatting helpers used across the notes and tasks routes.

function formatDate(date) {
  const d = date instanceof Date ? date : new Date(date);
  return d.toISOString().slice(0, 10);
}

function formatId(prefix, n) {
  return `${prefix}-${String(n).padStart(4, "0")}`;
}

module.exports = { formatDate, formatId };

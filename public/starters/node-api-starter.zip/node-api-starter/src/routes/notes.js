const express = require("express");
const { createStore } = require("../lib/store");
const { formatDate, formatId } = require("../utils/format");

const router = express.Router();
const store = createStore();

router.get("/", (req, res) => {
  res.json(store.list());
});

router.post("/", (req, res) => {
  const { text } = req.body ?? {};
  if (!text) {
    return res.status(400).json({ error: "text is required" });
  }
  const item = store.add({
    text,
    createdAt: formatDate(new Date()),
    ref: formatId("NOTE", Date.now() % 10000),
  });
  res.status(201).json(item);
});

router.delete("/:id", (req, res) => {
  const removed = store.remove(req.params.id);
  if (!removed) {
    return res.status(404).json({ error: "not found" });
  }
  res.status(204).end();
});

module.exports = router;

const { formatDate, formatId } = require("../src/utils/format");

describe("formatDate", () => {
  it("formats a Date as YYYY-MM-DD", () => {
    expect(formatDate(new Date("2026-01-05T12:00:00Z"))).toBe("2026-01-05");
  });

  it("accepts a date string", () => {
    expect(formatDate("2026-03-14")).toBe("2026-03-14");
  });
});

describe("formatId", () => {
  it("pads the number to 4 digits", () => {
    expect(formatId("NOTE", 7)).toBe("NOTE-0007");
  });

  it("does not truncate numbers longer than 4 digits", () => {
    expect(formatId("TASK", 12345)).toBe("TASK-12345");
  });
});
